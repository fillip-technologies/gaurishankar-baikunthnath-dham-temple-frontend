import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { MapPin, Phone, Mail, ExternalLink, ShieldCheck } from 'lucide-react';
import templeLogo from '../../../assets/logo.png';
import MandalaCorner from './MandalaCorner';

export default function Footer() {
  const { t } = useTranslation();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="w-full bg-gradient-to-b from-[#5c1615] via-[#6a1a19] to-[#4e1211] text-white border-t-2 border-[#c28227] pt-14 sm:pt-16 lg:pt-20 pb-8 sm:pb-10 font-sans relative overflow-hidden z-20">
      
      {/* Background Subtle Radial Glow & Watermark */}
      <div className="absolute inset-0 opacity-10 pointer-events-none bg-[radial-gradient(#ffd700_1px,transparent_1px)] [background-size:28px_28px]" />

      {/* Left Ornamental Vedic Mandala Motif */}
      <div className="absolute -left-16 sm:-left-20 -bottom-14 sm:-bottom-16 pointer-events-none opacity-35 select-none">
        <MandalaCorner className="w-72 h-72 sm:w-96 sm:h-96 lg:w-[420px] lg:h-[420px] drop-shadow-lg" />
      </div>

      {/* Right Ornamental Vedic Mandala Motif */}
      <div className="absolute -right-16 sm:-right-20 -bottom-14 sm:-bottom-16 pointer-events-none opacity-35 select-none">
        <MandalaCorner className="w-72 h-72 sm:w-96 sm:h-96 lg:w-[420px] lg:h-[420px] drop-shadow-lg transform scale-x-[-1]" />
      </div>

      <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-10 xl:px-14 relative z-10">
        
        {/* Main 3-Column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-12 pb-12 sm:pb-14 items-start">
          
          {/* Column 1: Sacred Emblem, Trust Title & Follow Us (md:col-span-5) */}
          <div className="md:col-span-5 space-y-4 sm:space-y-5">
            <div className="flex items-center gap-3 sm:gap-4">
              {/* Official Temple Logo */}
              <Link 
                to="/" 
                onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} 
                className="shrink-0 group block"
                title="श्री गौरीशंकर वैकुंठनाथ धाम"
              >
                <img 
                  src={templeLogo} 
                  alt="श्री गौरीशंकर वैकुंठनाथ धाम लोगो" 
                  className="h-16 sm:h-20 w-auto object-contain drop-shadow-md transition-transform duration-200 group-hover:scale-105" 
                />
              </Link>

              {/* Title & Subtitle */}
              <div>
                <h3 className="font-bold text-base sm:text-lg lg:text-xl text-white font-yatra leading-snug tracking-wide">
                  श्री गौरीशंकर वैकुंठनाथ धाम
                </h3>
                <p className="text-xs sm:text-sm text-amber-200/95 font-noto font-medium tracking-wide">
                  मंदिर न्यास समिति
                </p>
                <p className="text-xs text-[#ffd700] font-mantra tracking-widest mt-0.5">
                  ॥ ॐ नमः शिवाय ॥
                </p>
              </div>
            </div>

            {/* Sacred Introduction Text to fill empty space */}
            <p className="text-xs sm:text-[13px] text-amber-100/90 leading-relaxed font-hindi">
              श्री गौरीशंकर वैकुंठनाथ धाम माँ गंगा के पावन तट पर स्थित एक अलौकिक व ऐतिहासिक तीर्थ स्थल है, जहाँ भगवान शिव एवं श्री हरि विष्णु के युगल स्वरूप की नित्य आराधना होती है।
            </p>

            {/* Mandir Trust & Verification Badge */}
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-amber-200/95 font-hindi pt-0.5">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-[#ffd700]" />
                <span>पंजीकृत धर्मार्थ न्यास समिति</span>
              </span>
              <span className="opacity-40">•</span>
              <span className="text-amber-100/80">80G आयकर छूट प्राप्त</span>
            </div>

            {/* Follow Us & Social Icons */}
            <div className="pt-2">
              <p className="text-xs sm:text-sm font-semibold text-amber-100 mb-2.5 tracking-wide">
                Follow Us
              </p>
              <div className="flex items-center gap-2.5 sm:gap-3">
                {/* Facebook */}
                <a
                  href="https://facebook.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Facebook"
                  className="w-8 h-8 rounded-full bg-[#1877F2] hover:bg-[#166fe5] text-white flex items-center justify-center shadow-md hover:scale-110 active:scale-95 transition-all"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                  </svg>
                </a>

                {/* YouTube */}
                <a
                  href="https://youtube.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="YouTube"
                  className="w-8 h-8 rounded-full bg-[#FF0000] hover:bg-[#e60000] text-white flex items-center justify-center shadow-md hover:scale-110 active:scale-95 transition-all"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                  </svg>
                </a>

                {/* Instagram */}
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Instagram"
                  className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#f09433] via-[#dc2743] to-[#bc1888] hover:opacity-95 text-white flex items-center justify-center shadow-md hover:scale-110 active:scale-95 transition-all"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                  </svg>
                </a>

                {/* X (formerly Twitter) */}
                <a
                  href="https://x.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="X (Twitter)"
                  className="w-8 h-8 rounded-full bg-black hover:bg-stone-900 text-white flex items-center justify-center shadow-md hover:scale-110 active:scale-95 transition-all"
                >
                  <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                  </svg>
                </a>

                {/* WhatsApp */}
                <a
                  href="https://wa.me/919876543210"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="WhatsApp"
                  className="w-8 h-8 rounded-full bg-[#25D366] hover:bg-[#20ba59] text-white flex items-center justify-center shadow-md hover:scale-110 active:scale-95 transition-all"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
                  </svg>
                </a>
              </div>
            </div>
          </div>

          {/* Column 2: Mandir Contact & Location Map (md:col-span-4) */}
          <div className="md:col-span-4 space-y-4">
            <div className="space-y-2.5 text-xs sm:text-sm text-amber-50">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#f3ba63] shrink-0 mt-0.5" />
                <span className="font-hindi text-[13px] sm:text-sm leading-relaxed">
                  बैकठपुर, पटना - 801503 (बिहार)
                </span>
              </div>

              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#f3ba63] shrink-0" />
                <a href="tel:+919876543210" className="hover:text-white transition-colors font-sans">
                  +91 98765 43210
                </a>
              </div>

              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#f3ba63] shrink-0" />
                <a href="mailto:info@gaurishankardham.org" className="hover:text-white transition-colors font-sans">
                  info@gaurishankardham.org
                </a>
              </div>
            </div>

            {/* Embedded Google Map (Decreased width for balanced, compact card) */}
            <div className="w-full max-w-[280px] sm:max-w-[310px] rounded-xl overflow-hidden border border-white/20 shadow-lg bg-stone-900/60 relative group">
              <iframe
                title="Shree Gaurishankar Baikunthnath Dham Temple Location"
                src="https://maps.google.com/maps?q=Baikathpur%20Patna%20Bihar%20Gaurishankar%20Mandir&t=&z=14&ie=UTF8&iwloc=&output=embed"
                className="w-full h-28 sm:h-32 border-0 block"
                loading="lazy"
                allowFullScreen
                referrerPolicy="no-referrer-when-downgrade"
              />
              <a
                href="https://www.google.com/maps/search/?api=1&query=Shree+Gaurishankar+Baikunthnath+Dham+Temple+Baikathpur+Patna"
                target="_blank"
                rel="noopener noreferrer"
                className="absolute top-2 left-2 bg-white/95 hover:bg-white text-blue-700 hover:text-blue-800 text-[10px] font-medium px-2 py-0.5 rounded shadow-sm transition-colors flex items-center gap-1 border border-stone-200"
              >
                <span>View larger map</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
            </div>
          </div>

          {/* Column 3: Quick Links (md:col-span-3) */}
          <div className="md:col-span-3">
            <h4 className="text-base sm:text-lg font-bold text-[#f3ba63] mb-3 sm:mb-4 tracking-wide font-sans">
              Quick Links
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm font-sans">
              {[
                { label: 'Home', to: '/' },
                { label: 'About Us', to: '/about-us' },
                { label: 'Seva & Donation', to: '/online-services/seva-daan' },
                { label: 'Gallery', to: '/gallery/photos' },
                { label: 'Committee', to: '/members/trust-members' },
                { label: 'Contact', to: '#contact-section' },
              ].map((item) => (
                <li key={item.label}>
                  {item.to.startsWith('#') ? (
                    <a
                      href={item.to}
                      className="text-amber-100/90 hover:text-white transition-colors duration-200 flex items-center gap-1.5 group"
                    >
                      <span className="text-[#f3ba63] group-hover:translate-x-0.5 transition-transform font-bold">
                        &gt;
                      </span>
                      <span>{item.label}</span>
                    </a>
                  ) : (
                    <Link
                      to={item.to}
                      onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                      className="text-amber-100/90 hover:text-white transition-colors duration-200 flex items-center gap-1.5 group"
                    >
                      <span className="text-[#f3ba63] group-hover:translate-x-0.5 transition-transform font-bold">
                        &gt;
                      </span>
                      <span>{item.label}</span>
                    </Link>
                  )}
                </li>
              ))}
            </ul>
          </div>

        </div>

        {/* Bottom Bar / Copyright */}
        <div className="border-t border-white/15 pt-6 sm:pt-7 text-center text-xs sm:text-[13px] text-amber-100/90 font-hindi">
          <p>
            © {currentYear} श्री गौरीशंकर वैकुंठनाथ धाम मंदिर न्यास समिति. All Rights Reserved.
            <span className="mx-2.5 opacity-40 hidden sm:inline">|</span>
            <span className="block sm:inline mt-1 sm:mt-0 text-amber-200 font-semibold">
              हर हर महादेव ॥
            </span>
          </p>
        </div>

      </div>
    </footer>
  );
}
